import React, { useEffect, useRef } from "react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js"
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js"
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js"
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js"
import { addPropertyControls, ControlType } from "framer"

export default function SparklingSphere( props ) {
  const mountRef = useRef<HTMLDivElement>( null )

  useEffect( () => {
    if ( !mountRef.current ) return

    // Scene setup
    const scene = new THREE.Scene()
    scene.background = new THREE.Color( 0x000000 )

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    )

    const renderer = new THREE.WebGLRenderer( {
      antialias: true,
      alpha: true,
    } )
    renderer.setSize( window.innerWidth, window.innerHeight )
    renderer.setClearColor( 0x000000, 1 )
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    renderer.toneMappingExposure = 11
    mountRef.current.appendChild( renderer.domElement )

    // Camera position and controls
    camera.position.z = 5
    const controls = new OrbitControls( camera, renderer.domElement )
    controls.enableDamping = true
    controls.dampingFactor = 0.05

    // Post-processing setup
    const composer = new EffectComposer( renderer )
    const renderPass = new RenderPass( scene, camera )
    composer.addPass( renderPass )

    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2( window.innerWidth, window.innerHeight ),
      11,
      0.4,
      0.1
    )
    composer.addPass( bloomPass )

    // Lighting
    const ambientLight = new THREE.AmbientLight( 0x111111 )
    scene.add( ambientLight )

    const pointLight = new THREE.PointLight( 0x88ccff, 1 )
    pointLight.position.set( 5, 5, 5 )
    scene.add( pointLight )

    // Group for all particles
    const group = new THREE.Group()
    scene.add( group )

    const raycaster = new THREE.Raycaster()
    const mousePos = new THREE.Vector2()

    const particles = []
    const createParticles = () => {
      const count = 2500
      const radius = 2
      const geometry = new THREE.SphereGeometry( 0.015, 6, 6 )
      const colors = [ 0x88ccff, 0x7dabf1, 0x6a8dff ]
      const glowColors = [ 0xff0000, 0x00ff00, 0x0000ff ]

      for ( let i = 0; i < count; i++ ) {
        const theta = Math.random() * Math.PI * 2
        const phi = Math.acos( 2 * Math.random() - 1 )
        const x = radius * Math.sin( phi ) * Math.cos( theta )
        const y = radius * Math.sin( phi ) * Math.sin( theta )
        const z = radius * Math.cos( phi )

        const position = new THREE.Vector3( x, y, z )

        const baseColor = new THREE.Color(
          colors[ Math.floor( Math.random() * colors.length ) ]
        )
        const material = new THREE.MeshStandardMaterial( {
          color: baseColor,
          emissive: baseColor,
          metalness: 0.5,
          roughness: 0.2,
          toneMapped: false,
        } )

        const mesh = new THREE.Mesh( geometry, material )
        mesh.position.copy( position )

        group.add( mesh )

        particles.push( {
          mesh,
          position: position.clone(),
          originalPosition: position.clone(),
          velocity: new THREE.Vector3(),
          baseColor,
          glowColor: new THREE.Color(
            glowColors[
            Math.floor( Math.random() * glowColors.length )
            ]
          ),
          repulsionFactor: 0,
        } )
      }
    }

    createParticles()
    const mousePosition3D = new THREE.Vector3()
    const animate = () => {
      requestAnimationFrame( animate )

      raycaster.setFromCamera( mousePos, camera )
      const intersectPlane = new THREE.Plane(
        new THREE.Vector3( 0, 0, 1 ),
        0
      )

      raycaster.ray.intersectPlane( intersectPlane, mousePosition3D )

      particles.forEach( ( particle ) => {
        const distanceToMouse = mousePosition3D.distanceTo(
          particle.positiona
        )
        const isInRange = distanceToMouse < 1

        if ( isInRange ) {
          const repulsionDir = particle.position
            .clone()
            .sub( mousePosition3D )
            .normalize()
          particle.velocity.add( repulsionDir.multiplyScalar( 0.08 ) )

          particle.repulsionFactor = Math.min(
            particle.repulsionFactor + 0.1,
            1
          )
        } else {
          particle.repulsionFactor = Math.max(
            particle.repulsionFactor - 0.05,
            0
          )
        }

        const currentColor = particle.baseColor
          .clone()
          .lerp( particle.glowColor, particle.repulsionFactor )
        particle.mesh.material.emissive.set( currentColor )

        const returnForce = particle.originalPosition
          .clone()
          .sub( particle.position )
          .normalize()
          .multiplyScalar( 0.02 )

        particle.velocity.add( returnForce )
        particle.velocity.multiplyScalar( 0.95 )

        particle.position.add( particle.velocity )
        particle.mesh.position.copy( particle.position )
      } )

      controls.update()
      composer.render()
    }

    const handleMouseMove = ( event ) => {
      mousePos.x = ( event.clientX / window.innerWidth ) * 2 - 1
      mousePos.y = -( event.clientY / window.innerHeight ) * 2 + 1
    }

    window.addEventListener( "mousemove", handleMouseMove )

    animate()

    return () => {
      window.removeEventListener( "mousemove", handleMouseMove )
      mountRef.current?.removeChild( renderer.domElement )
    }
  }, [] )

  return <div ref={ mountRef } />
}

addPropertyControls( SparklingSphere, {
  exposure: {
    type: ControlType.Number,
    title: "Exposure",
    defaultValue: 1.5,
    min: 0.5,
    max: 3,
    step: 0.1,
  },
} )
addPropertyControls( SparklingSphere, {
  bloomStrength: {
    type: ControlType.Number,
    title: "Bloom Strength",
    defaultValue: 1.5,
    min: 0.1,
    max: 3,
    step: 0.1,
  },
} )
addPropertyControls( SparklingSphere, {
  interactionRadius: {
    type: ControlType.Number,
    title: "Interaction Radius",
    defaultValue: 1.5,
    min: 0.5,
    max: 5,
    step: 0.1,
  },
} )

addPropertyControls( SparklingSphere, {
  children: {
    type: ControlType.Array,
    control: {
      type: ControlType.ComponentInstance,
    },
    maxCount: 5,
  },
} )

addPropertyControls( SparklingSphere, {
  myArray: {
    type: ControlType.Array,
    control: {
      type: ControlType.Object,
      controls: {
        title: { type: ControlType.String, defaultValue: "Employee" },
        avatar: { type: ControlType.Image },
      },
    },
    defaultValue: [ { title: "Jorn" }, { title: "Koen" } ],
  },
} )

SparklingSphere.defaultProps = {
  paddings: [ 5, 10, 15 ],
}

// Property controls
addPropertyControls( SparklingSphere, {
  exposure: {
    type: ControlType.Number,
    title: "Exposure",
    defaultValue: 1.5,
    min: 0.5,
    max: 3,
    step: 0.1,
  },
} )
addPropertyControls( SparklingSphere, {
  bloomStrength: {
    type: ControlType.Number,
    title: "Bloom Strength",
    defaultValue: 1.5,
    min: 0.1,
    max: 3,
    step: 0.1,
  },
} )
addPropertyControls( SparklingSphere, {
  interactionRadius: {
    type: ControlType.Number,
    title: "Interaction Radius",
    defaultValue: 1.5,
    min: 0.5,
    max: 5,
    step: 0.1,
  },
} )

// Add a multi-connector to your component to connect components on the canvas
addPropertyControls( SparklingSphere, {
  children: {
    type: ControlType.Array,
    control: {
      type: ControlType.ComponentInstance,
    },
    maxCount: 5,
  },
} )

// Add a list of objects
addPropertyControls( SparklingSphere, {
  myArray: {
    type: ControlType.Array,
    control: {
      type: ControlType.Object,
      controls: {
        title: { type: ControlType.String, defaultValue: "Employee" },
        avatar: { type: ControlType.Image },
      },
    },
    defaultValue: [ { title: "Jorn" }, { title: "Koen" } ],
  },
} )
